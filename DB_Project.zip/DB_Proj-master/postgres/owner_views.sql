create or replace view owner_store
	as select *
    from Store;

create or replace view owner_store_phonenumber
	as select *
	from Store_PhoneNumber;

create or replace view owner_order  
	as select *
	from Orderio;		-- change status 

create or replace view owner_prod
	as select *
    from Product;
    
/*create or replace view owner_coupon
	as select *
    from Coupons;*/
CREATE DOMAIN orderStatusDomain VARCHAR(10)
     CHECK (VALUE IN ('Pending', 'InProgress', 'OnTheWay', 'Delivered'));
     
     
     
CREATE DOMAIN emailDomain varchar(255) 
CHECK (
  VALUE ~ '(?:[a-z0-9!#$%&'*+=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+=?^_`{|}~-]+)*|"(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21\x23-\x5b\x5d-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])*")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\[(?:(?:(2(5[0-5]|[0-4][0-9])|1[0-9][0-9]|[1-9]?[0-9]))\.){3}(?:(2(5[0-5]|[0-4][0-9])|1[0-9][0-9]|[1-9]?[0-9])|[a-z0-9-]*[a-z0-9]:(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21-\x5a\x53-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])+)\])'
);


CREATE DOMAIN CustomerRatingDomain TINYINT(1)
     CHECK (VALUE IN ('1', '2', '3', '4', '5'));


CREATE DOMAIN OverallRatingDomain float
     CHECK (value >= 1 AND value <= 5);









CREATE TABLE Userio
(
    UID varchar(10) NOT NULL,
    Email emailDomain NOT NULL UNIQUE,
    Pass_word varchar(255) NOT NULL,
    FirstName varchar(20),
    LastName varchar(20),
    Gender varchar(10),
    BirthDate date,
    PhotoLink varchar(255),
    PRIMARY KEY (UID),
    CHECK (Email like '%@%.%')
);


CREATE TABLE User_PhoneNumber
(
    UID varchar(10) NOT NULL,
    PhoneNumber varchar(13) NOT NULL,
    PRIMARY KEY (UID,PhoneNumber),
    FOREIGN KEY (UID) REFERENCES Userio (UID)
    ON DELETE CASCADE
    ON UPDATE CASCADE
);


CREATE TABLE Customer
(
    UID varchar(10) NOT NULL,
    Balance float NOT NULL,
    PRIMARY KEY (UID),
    CHECK (Balance >= 0),
    FOREIGN KEY (UID) REFERENCES Userio (UID)
    ON DELETE CASCADE
    ON UPDATE CASCADE
);


CREATE TABLE Customer_Address
(
    UID varchar(10) NOT NULL,
    Address varchar(255) NOT NULL,
    Selected bit NOT NULL,
    PRIMARY KEY (UID, Address),
    FOREIGN KEY (UID) REFERENCES Userio (UID)
    ON DELETE CASCADE
    ON UPDATE CASCADE
);


CREATE TABLE DeliveryMan
(
    UID varchar(10) NOT NULL,
    Vehicle varchar(255) NOT NULL,
    CreaditCardInfo varchar(255) NOT NULL,
    Rating OverallRatingDomain NOT NULL,
    IsFree bit,
    PRIMARY KEY (UID),
    FOREIGN KEY (UID) REFERENCES Userio (UID)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
    CHECK (Rating between 1 and 5)
);


CREATE TABLE Store
(
    SID varchar(10) NOT NULL,
    Name varchar(20) NOT NULL,
    Address varchar(255) NOT NULL,
    MinimumOrderCost float NOT NULL,
    WorkingHours varchar(255) NOT NULL,
    DeliveryCost float NOT NULL,
    DelivaryRange varchar(255) NOT NULL,
    PaymentMethod bit(3),
    PhotoLink varchar(255),
    Rating OverallRatingDomain NOT NULL,
    PRIMARY KEY (SID),
    FOREIGN KEY (SID) REFERENCES Store (SID)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
    CHECK (Rating between 1 and 5)
);



CREATE TABLE Store_PhoneNumber
(
    SID varchar(10) NOT NULL,
    PhoneNumber varchar(13) NOT NULL,
    PRIMARY KEY (SID,PhoneNumber)
);



CREATE TABLE Product
(
    PID varchar(10) NOT NULL,
    SID varchar(10) NOT NULL,
    Name varchar(20) NOT NULL,
    Price float NOT NULL,
    Countio smallint NOT NULL,
    Discount float NOT NULL,
    Description varchar(255),
    Category varchar(20) NOT NULL,
    PRIMARY KEY (PID),
    FOREIGN KEY (SID) REFERENCES Store (SID)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
    CHECK (Discount >= 0)
);



CREATE TABLE Orderio
(
    OID varchar(10) NOT NULL,
    CustUID varchar(10) NOT NULL,
    SID varchar(10) NOT NULL,
    DateDay date NOT NULL,
    DateTime time NOT NULL,
    DestinationAddress varchar(255) NOT NULL,
    DelUID varchar(10),
    Status orderStatusDomain NOT NULL,
    Discount float NOT NULL,
    PRIMARY KEY (OID),
    FOREIGN KEY (CustUID) REFERENCES Userio (UID)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
    FOREIGN KEY (DelUID) REFERENCES Userio (UID)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
    FOREIGN KEY (SID) REFERENCES Store (SID)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
    CHECK (Discount >= 0)
);



CREATE TABLE OrdProd
(
    OID varchar NOT NULL,
    PID varchar(10) NOT NULL,
    Countio smallint NOT NULL,
    PRIMARY KEY (OID, PID),
    FOREIGN KEY (OID) REFERENCES Orderio (OID)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
    FOREIGN KEY (PID) REFERENCES Product (PID)
    ON DELETE CASCADE
    ON UPDATE CASCADE
);



CREATE TABLE OwnsStore
(
    UID varchar(10) NOT NULL,
    SID varchar(10) NOT NULL,
    PRIMARY KEY (UID, SID),
    FOREIGN KEY (UID) REFERENCES Userio (UID)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
    FOREIGN KEY (SID) REFERENCES Store (SID)
    ON DELETE CASCADE
    ON UPDATE CASCADE
);



CREATE TABLE FavStore
(
    UID varchar(10) NOT NULL,
    SID varchar(10) NOT NULL,
    PRIMARY KEY (UID, SID),
    FOREIGN KEY (UID) REFERENCES Userio (UID)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
    FOREIGN KEY (SID) REFERENCES Store (SID)
    ON DELETE CASCADE
    ON UPDATE CASCADE
);
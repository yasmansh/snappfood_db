create or replace view cust_profile
	as select *
    from Customer;

create or replace view cust_address
	as select *
    from Customer_Address;
	
create or replace view cust_order
	as select *
    from Orderio;

create or replace view cust_order_prod
	as select *
    from OrdProd;

create or replace view cust_favstore
	as select *
    from FavStore;
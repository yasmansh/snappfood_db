CREATE OR REPLACE FUNCTION noaccess_error() RETURNS TRIGGER AS $BODY$
	BEGIN
		raise exception 'No Edit Access Error';
   		RETURN NULL;
	END;
$BODY$ LANGUAGE plpgsql;

drop trigger if exists trig_noedit_store on noedit_store;
create trigger trig_noedit_store
	instead of insert or delete or update
	on noedit_store
    for each row
    execute procedure noaccess_error();

drop trigger if exists trig_noedit_store_phonenumber on noedit_store_phonenumber;
create trigger trig_noedit_store_phonenumber
	instead of insert or delete or update
	on noedit_store_phonenumber
    for each row
    execute procedure noaccess_error();

drop trigger if exists trig_noedit_delivery on noedit_delivery;
create trigger trig_noedit_delivery
	instead of insert or delete or update
	on noedit_delivery
    for each row
    execute procedure noaccess_error();
    
drop trigger if exists trig_noedit_product on noedit_product;
create trigger trig_noedit_product
	instead of insert or delete or update
	on noedit_product
    for each row
    execute procedure noaccess_error();

drop trigger if exists trig_noedit_order on noedit_order;
create trigger trig_noedit_order
	instead of insert or delete or update
	on noedit_order
    for each row
    execute procedure noaccess_error();
    
drop trigger if exists trig_noedit_order_prod on noedit_order_prod;
create trigger trig_noedit_order_prod
	instead of insert or delete or update
	on noedit_order_prod
    for each row
    execute procedure noaccess_error();
    
drop trigger if exists trig_del_order on del_order;
create trigger trig_del_order
	instead of insert or delete
	on del_order
    for each row
    execute procedure noaccess_error();

drop trigger if exists trig_update_del_order on del_order;
create trigger trig_update_del_order
	before update of OID, Discount, DateDay, DateTime, DestinationAddress, SID, CustUID
	on del_order
    for each statement
    execute procedure noaccess_error();

drop trigger if exists trig_owner_order on owner_order;
create trigger trig_owner_order
	instead of insert or delete
	on owner_order
    for each row
    execute procedure noaccess_error();

drop trigger if exists trig_update_owner_order on owner_order;
create trigger trig_update_owner_order
	before update of OID, Discount, DateDay, DateTime, DestinationAddress, SID, CustUID, DelUID
	on owner_order
    for each statement
    execute procedure noaccess_error();

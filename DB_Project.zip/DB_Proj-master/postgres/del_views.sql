create or replace view del_profile  
	as select *
	from DeliveryMan;

create or replace view del_order    
	as select *
    from Orderio;		-- change status and deluid
create or replace view user_profile
	as select *
    from Userio;

create or replace view user_phonenumber_view
	as select *
    from User_PhoneNumber;

create or replace view noedit_store
	as select *
	from Store;

create or replace view noedit_store_phonenumber
	as select *
	from Store_PhoneNumber;
    
create or replace view noedit_delivery
	as select UID, Vehicle, Rating
	from DeliveryMan;

create or replace view noedit_product
	as select *
	from Product;

create or replace view noedit_order
	as select *
    from Orderio;

/*create or replace view noedit_coupon
	as select *
	from Coupons;*/

create or replace view noedit_order_prod
	as select *
	from OrdProd;

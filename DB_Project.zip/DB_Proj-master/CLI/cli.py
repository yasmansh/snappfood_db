import psycopg2
from psycopg2 import Error
import queries as qu

def print_table(x):
	print("\n", "- " * 20)
	for i in x:
		print(i)
	print("- " * 20, "\n")

connection, cursor, cur_uid, order = None, None, None, None

def start_program():
	global connection, cursor, cur_uid
	connection, cursor = qu.set_connection()
	cur_uid = -1
	
def run_command(command):
	global connection, cursor, cur_uid, order
	try :
		if command[0]=="exit":
			exit(0)
		elif command[0]=="init":
			qu.create_tables()
		elif command[0]=="clear":
			qu.drop_tables()
		elif command[0]=="register":
			max_uid = qu.get_max_uid()
			if max_uid==None:
				max_uid = -1
			else :
				max_uid = max_uid[1:]
			cur_uid = int(max_uid) + 1
			attrs = ['u'+str(cur_uid)] + command[1:]
			while len(attrs)<8:
				attrs+=["NULL"]
			qu.register_user(attrs)
		elif command[0]=="delete_user":
			qu.delete_user(cur_uid)
		elif command[0]=="get_users":
			return (qu.get_users())
		elif command[0]=="login":
			if command[1]=='admin' and command[2]=='admin':
				print("logged in as admin")
				qu.set_admin(True)
				return
			tmp = qu.login(command[1:])
			if tmp==None:
				print("wrong email or password")
			else :
				cur_uid = tmp
				qu.set_admin(False)
				print("logged in successfully with id={}!".format(cur_uid))
		elif command[0]=="get_profile":
			return (qu.get_user(cur_uid))
		elif command[0]=="update_profile":
			qu.update_user(cur_uid, command[1], command[2])
		elif command[0]=="add_phonenumber":
			qu.add_phonenumber(cur_uid, command[1])
		elif command[0]=="delete_phonenumbers":
			qu.delete_phonenumbers(cur_uid)
		elif command[0]=="get_phonenumbers":
			return (qu.get_phonenumbers(cur_uid))
		elif command[0]=="add_as_customer":
			qu.add_customer(cur_uid)
		elif command[0]=="get_balance":
			return (qu.get_balance(cur_uid))
		elif command[0]=="change_balance":
			qu.change_balance(cur_uid, int(command[1]))
		elif command[0]=="add_address":
			qu.add_address(cur_uid, command[1])
		elif command[0]=="change_main_address":
			qu.change_main_address(cur_uid, command[1])
		elif command[0]=="delete_addresses":
			qu.delete_addresses(cur_uid)
		elif command[0]=="get_addresses":
			return (qu.get_addresses(cur_uid))
		elif command[0]=="add_as_delivery":
			attrs = [cur_uid] + command[1:]
			while len(attrs)<3:
				attrs+=["NULL"]
			qu.add_delivery(attrs)
		elif command[0]=="get_delivery_profile":
			return (qu.get_delivery(cur_uid))
		elif command[0]=="delete_delivery":
			qu.delete_delivery(cur_uid)
		elif command[0]=="add_store":
			max_sid = qu.get_max_sid()
			if max_sid==None:
				max_sid = -1
			else :
				max_sid = max_sid[1:]
			cur_sid = int(max_sid) + 1
			attrs = ['s'+str(cur_sid)] + command[1:]
			while len(attrs)<9:
				attrs+=["NULL"]
			qu.add_store(cur_uid, attrs)
			print("store added successfully with id={}!".format(attrs[0]))
		elif command[0]=="get_all_stores":
			return (qu.get_all_stores())
		elif command[0]=="get_my_stores":
			return (qu.get_my_stores(cur_uid))
		elif command[0]=="delete_store":
			qu.delete_store(command[1])
		elif command[0]=="add_store_phonenumber":
			qu.add_store_phonenumber(cur_uid, command[1], command[2])
		elif command[0]=="delete_store_phonenumbers":
			qu.delete_store_phonenumbers(cur_uid, command[	1])
		elif command[0]=="get_store_phonenumbers":
			return (qu.get_store_phonenumbers(command[1]))
		elif command[0]=="add_product":
			max_pid = qu.get_max_pid()
			if max_pid==None:
				max_pid = -1
			else :
				max_pid = max_pid[1:]
			cur_pid = int(max_pid) + 1
			attrs = ['p'+str(cur_pid)] + command[1:]
			while len(attrs)<8:
				attrs+=["NULL"]
			qu.add_product(cur_uid, attrs)
			print("product added successfully with id={}!".format(attrs[0]))
		elif command[0]=="get_products":
			return (qu.get_products(cur_uid, command[1]))
		elif command[0]=="delete_product":
			qu.delete_product(cur_uid, command[1])
		elif command[0]=="new_order":
			order = {}
		elif command[0]=="add_to_order":
			if not command[1] in order:
				order[command[1]] = 0
			order[command[1]] += int(command[2])
		elif command[0]=="remove_from_order":
			if not command[1] in order or order[command[1]]<int(command[2]):
				raise Exception("not enough items to remove")
			order[command[1]] -= int(command[2])
		elif command[0]=="view_order":
			print(order)
		elif command[0]=="submit_order":
			max_oid = qu.get_max_oid()
			if max_oid==None:
				max_oid = -1
			else :
				max_oid = max_oid[1:]
			cur_oid = int(max_oid) + 1
			qu.submit_order('o'+str(cur_oid), cur_uid, order)
			print("order added successfully with id={}!".format('o'+str(cur_oid)))
		elif command[0]=="get_my_orders":
			return qu.get_my_orders(cur_uid)
		elif command[0]=="get_order_prods":
			return qu.get_order_prods(cur_uid, command[1])
		elif command[0]=="prepare_order":
			qu.prepare_order(cur_uid, command[1])
		elif command[0]=="get_all_delivery_orders":
			return qu.get_all_delivery_orders()
		elif command[0]=="get_my_delivery_orders":
			return qu.get_my_delivery_orders(cur_uid)
		elif command[0]=="take_order":
			qu.take_order(cur_uid, command[1])
		elif command[0]=="deliver_order":
			qu.deliver_order(cur_uid, command[1])
		elif command[0]=="custom":
			cmd = " ".join(command[1:])
			return qu.custom_command(cmd)
		else:
			raise Exception("wrong query type!")
		
	
	except (Exception, Error) as error:
		print(error)
		connection, cursor = qu.set_connection()
	

if __name__ == "__main__":
	try:
		start_program()
		while True:
			command = input(">>> ").split()
			tmp = run_command(command)
			if tmp!=None:
				print_table(tmp)
	
	except (Exception, Error) as error:
		print("Error while connecting to PostgreSQL", error)
	finally:
		if (connection):
			cursor.close()
			connection.close()
			print("PostgreSQL connection is closed")
			
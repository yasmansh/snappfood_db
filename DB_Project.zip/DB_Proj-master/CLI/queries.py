import psycopg2
from psycopg2 import Error
from datetime import date
from datetime import datetime

connection, cursor = None, None
admin = False

def set_admin(val):
	global admin
	admin = val

def set_connection():
	global connection, cursor
	connection = psycopg2.connect(user="postgres",
					password="12345678",
					host="localhost",
					port="5432",
					database="food_delivery_db")
	cursor = connection.cursor()
	return connection, cursor

def get_max_uid():
	str = "SELECT MAX(UID) FROM Userio;"
	cursor.execute(str)
	record = cursor.fetchone()
	if record==None:
		return record
	return record[0]
	
def create_tables():
	with open("sql_codes/tables.txt","r") as f:
		str = f.read()
	cursor.execute(str)
	connection.commit()
	
def drop_tables():
	with open("sql_codes/drop_tables.txt","r") as f:
		str = f.read()
	cursor.execute(str)
	connection.commit()

def register_user(attrs):
	str = "INSERT INTO Userio VALUES {};".format(tuple(attrs)).replace("'NULL'", "NULL")
	cursor.execute(str)
	connection.commit()
	
def get_users():
	if not admin:
		return []
	str = "SELECT * FROM Userio;";
	cursor.execute(str)
	record = cursor.fetchall()
	return record
	
def login(attrs):
	str = "SELECT UID FROM Userio WHERE Email='{}' and Pass_word='{}'".format(*attrs)
	cursor.execute(str)
	record = cursor.fetchone()
	if record==None:
		return record
	return record[0]
	
def get_user(uid):
	str = "SELECT * FROM Userio WHERE UID='{}';".format(uid)
	cursor.execute(str)
	record = cursor.fetchall()
	return record

def delete_user(uid):
	str = "DELETE FROM Userio WHERE UID='{}';".format(uid)
	cursor.execute(str)
	connection.commit()

def add_phonenumber(uid, phonenumber):
	str = "INSERT INTO User_PhoneNumber VALUES('{}', '{}');".format(uid, phonenumber)
	cursor.execute(str)
	connection.commit()
	
def delete_phonenumbers(uid):
	str = "DELETE FROM User_PhoneNumber WHERE UID='{}';".format(uid)
	cursor.execute(str)
	connection.commit()
	
def get_phonenumbers(uid):
	str = "SELECT PhoneNumber FROM User_PhoneNumber WHERE UID='{}';".format(uid)
	cursor.execute(str)
	record = cursor.fetchall()
	return record
	
def add_customer(uid):
	str = "INSERT INTO Customer VALUES('{}', '{}');".format(uid, 0)
	cursor.execute(str)
	connection.commit()
	
def get_balance(uid):
	str = "SELECT Balance FROM Customer WHERE UID='{}';".format(uid)
	cursor.execute(str)
	record = cursor.fetchall()
	return record

def change_balance(uid, val):
	if not admin:
		return 
	balance = get_balance(uid)[0][0]
	balance += val
	str = "UPDATE Customer SET Balance={} WHERE UID='{}';".format(balance, uid)
	cursor.execute(str)
	connection.commit()

def add_address(uid, address):
	str = "SELECT Address FROM Customer_Address WHERE UID='{}';".format(uid)
	cursor.execute(str)
	record = cursor.fetchall()
	str = "INSERT INTO Customer_Address VALUES('{}', '{}', '{}');".format(uid, address, 1 if len(record)==0 else 0)
	cursor.execute(str)
	connection.commit()
	
def change_main_address(uid, address):
	str = "UPDATE Customer_Address SET Selected='0' WHERE UID='{}' AND Selected='1'".format(uid)
	cursor.execute(str)
	connection.commit()
	str = "UPDATE Customer_Address SET Selected='1' WHERE UID='{}' AND Address='{}'".format(uid, address)
	cursor.execute(str)
	connection.commit()
	
def delete_addresses(uid):
	str = "DELETE FROM Customer_Address WHERE UID='{}';".format(uid)
	cursor.execute(str)
	connection.commit()
	
def get_addresses(uid):
	str = "SELECT Address, Selected FROM Customer_Address WHERE UID='{}';".format(uid)
	cursor.execute(str)
	record = cursor.fetchall()
	return record
	
def add_delivery(attrs):
	str = "INSERT INTO DeliveryMan VALUES {};".format((*tuple(attrs), '5', '1')).replace("'NULL'", "NULL")
	cursor.execute(str)
	connection.commit()

def get_delivery(uid):
	str = "SELECT * FROM DeliveryMan WHERE UID='{}';".format(uid)
	cursor.execute(str)
	record = cursor.fetchall()
	return record

def delete_delivery(uid):
	str = "DELETE FROM DeliveryMan WHERE UID='{}';".format(uid)
	cursor.execute(str)
	connection.commit()
	
def update_user(uid, attr, val):
	if attr=="UID":
		return 
	str = "UPDATE Userio SET {}={} WHERE UID='{}';".format(attr, val, uid)
	cursor.execute(str)
	connection.commit()
	
def get_max_sid():
	str = "SELECT MAX(SID) FROM Store;"
	cursor.execute(str)
	record = cursor.fetchone()
	if record==None:
		return record
	return record[0]

def add_store(uid, attrs):
	attrs[3]=float(attrs[3])
	attrs[5]=float(attrs[5])
	str = "INSERT INTO Store VALUES {};".format((*tuple(attrs), 5)).replace("'NULL'", "NULL")
	cursor.execute(str)
	connection.commit()
	str = "INSERT INTO OwnsStore VALUES ('{}', '{}');".format(uid, attrs[0])
	cursor.execute(str)
	connection.commit()

def get_all_stores():
	str = "SELECT * FROM Store;".format()
	cursor.execute(str)
	record = cursor.fetchall()
	return record
	
def get_my_stores(uid):
	str = "SELECT * FROM OwnsStore NATURAL JOIN Store WHERE UID='{}';".format(uid)
	cursor.execute(str)
	record = cursor.fetchall()
	return record

def delete_store(sid):
	str = "DELETE FROM Store WHERE SID='{}';".format(sid)
	cursor.execute(str)
	connection.commit()
	
def add_store_phonenumber(uid, sid, phonenumber):
	str = "SELECT * FROM OwnsStore WHERE UID='{}' AND SID='{}';".format(uid, sid)
	cursor.execute(str)
	record = cursor.fetchall()
	if record==[] and not admin:
		raise Exception("not your store")
	str = "INSERT INTO Store_PhoneNumber VALUES('{}', '{}');".format(sid, phonenumber)
	cursor.execute(str)
	connection.commit()
	
def delete_store_phonenumbers(uid, sid):
	str = "SELECT * FROM OwnsStore WHERE UID='{}' AND SID='{}';".format(uid, sid)
	cursor.execute(str)
	record = cursor.fetchall()
	if record==[] and not admin:
		raise Exception("not your store")
	str = "DELETE FROM Store_PhoneNumber WHERE SID='{}';".format(sid)
	cursor.execute(str)
	connection.commit()
	
def get_store_phonenumbers(sid):
	str = "SELECT PhoneNumber FROM Store_PhoneNumber WHERE SID='{}';".format(sid)
	cursor.execute(str)
	record = cursor.fetchall()
	return record
	
def get_max_pid():
	str = "SELECT MAX(PID) FROM Product;"
	cursor.execute(str)
	record = cursor.fetchone()
	if record==None:
		return record
	return record[0]

def add_product(uid, attrs):
	sid = attrs[1]
	attrs[3] = float(attrs[3])
	attrs[4] = int(attrs[4])
	attrs[5] = float(attrs[5])
	str = "SELECT * FROM OwnsStore WHERE UID='{}' AND SID='{}';".format(uid, sid)
	cursor.execute(str)
	record = cursor.fetchall()
	if record==[] and not admin:
		raise Exception("not your store")
	str = "INSERT INTO Product VALUES {};".format(tuple(attrs)).replace("'NULL'", "NULL")
	cursor.execute(str)
	connection.commit()

def get_products(uid, sid):
	str = "SELECT * FROM Product WHERE SID='{}';".format(sid)
	cursor.execute(str)
	record = cursor.fetchall()
	return record
	
def delete_product(uid, pid):
	str = "SELECT SID FROM Product WHERE PID='{}';".format(pid)
	cursor.execute(str)
	record = cursor.fetchall()
	if record==[]:
		raise Exception("no such product")
	print(record)
	sid = record[0][0]
	str = "SELECT * FROM OwnsStore WHERE UID='{}' AND SID='{}';".format(uid, sid)
	cursor.execute(str)
	record = cursor.fetchall()
	if record==[] and not admin:
		raise Exception("not your store")
	str = "DELETE FROM Product WHERE PID='{}';".format(pid)
	cursor.execute(str)
	connection.commit()

def get_max_oid():
	str = "SELECT MAX(OID) FROM Orderio;"
	cursor.execute(str)
	record = cursor.fetchone()
	if record==None:
		return record
	return record[0]
	
def submit_order(oid, uid, prods):
	sid = None
	for pid, count in prods.items():
		str = "SELECT SID, Countio FROM Product WHERE PID='{}';".format(pid)
		cursor.execute(str)
		record = cursor.fetchone()
		if record == None:
			raise Exception("no such product")
		if sid == None:
			sid = record[0]
		elif sid!= record[0]:
			raise Exception("all products should be from the same store")
		if int(record[1]) < count:
			raise Exception("not enough products in the store")
		str = "UPDATE Product SET Countio={} WHERE PID='{}';".format(int(record[1]) - count, pid)
		cursor.execute(str)
	if sid == None:
		raise Exception("at least one product should be selected")
	str = "SELECT Address FROM Customer_Address WHERE UID='{}' AND Selected='{}';".format(uid, 1)
	cursor.execute(str)
	record = cursor.fetchone()
	dest = record[0]
	str = "INSERT INTO Orderio VALUES ('{}', '{}', '{}', '{}', '{}', '{}', {}, '{}', '{}');".format(oid, 
				uid, sid, date.today().strftime("%Y-%m-%d"), datetime.now().strftime("%H:%M:%S"),
				dest, 'NULL','InProgress', 0)
	cursor.execute(str)
	
	for pid, count in prods.items():
		str = "INSERT INTO OrdProd VALUES ('{}', '{}', {});".format(oid, pid, count)
		cursor.execute(str)
	
	connection.commit()
	
def get_my_orders(uid):
	str = "SELECT * FROM Orderio WHERE CustUID='{}';".format(uid)
	cursor.execute(str)
	record = cursor.fetchall()
	return record

def get_my_delivery_orders(uid):
	str = "SELECT * FROM Orderio WHERE DelUID='{}';".format(uid)
	cursor.execute(str)
	record = cursor.fetchall()
	return record
	
def get_all_delivery_orders():
	str = "SELECT * FROM Orderio WHERE Status='Prepared';"
	cursor.execute(str)
	record = cursor.fetchall()
	return record
	
def prepare_order(uid, oid):
	str = "SELECT * FROM Orderio NATURAL JOIN OwnsStore WHERE UID='{}' AND OID='{}';".format(uid, oid)
	cursor.execute(str)
	record = cursor.fetchall()
	if len(record)==0:
		raise Exception("you're not the owner")
		
	str = "SELECT * FROM Orderio WHERE OID='{}' AND Status='InProgress';".format(oid)
	cursor.execute(str)
	record = cursor.fetchall()
	if len(record)==0:
		raise Exception("order is not available")
	
	str = "UPDATE Orderio SET Status='Prepared' WHERE OID='{}' AND Status='InProgress';".format(oid)
	cursor.execute(str)
	connection.commit()

def take_order(uid, oid):
	str = "SELECT * FROM DeliveryMan WHERE UID='{}';".format(uid)
	cursor.execute(str)
	record = cursor.fetchall()
	if len(record)==0:
		raise Exception("you're not a deliveryman")
		
	str = "SELECT * FROM Orderio WHERE OID='{}' AND Status='Prepared';".format(oid)
	cursor.execute(str)
	record = cursor.fetchall()
	if len(record)==0:
		raise Exception("order is not available")
		
	str = "UPDATE Orderio SET DelUID='{}' WHERE OID='{}' AND Status='Prepared';".format(uid, oid)
	cursor.execute(str)
	connection.commit()
	
	str = "UPDATE Orderio SET Status='OnTheWay' WHERE OID='{}' AND Status='Prepared';".format(oid)
	cursor.execute(str)
	connection.commit()
	
	str = "UPDATE DeliveryMan SET IsFree='0' WHERE UID='{}';".format(uid)
	cursor.execute(str)
	connection.commit()
	
def deliver_order(uid, oid):
	str = "SELECT * FROM DeliveryMan WHERE UID='{}';".format(uid)
	cursor.execute(str)
	record = cursor.fetchall()
	if len(record)==0:
		raise Exception("you're not a deliveryman")
		
	str = "SELECT * FROM Orderio WHERE OID='{}' AND Status='OnTheWay' AND DelUID='{}';".format(oid, uid)
	cursor.execute(str)
	record = cursor.fetchall()
	if len(record)==0:
		raise Exception("order is not available")
		
	str = "UPDATE Orderio SET Status='Delivered' WHERE OID='{}' AND Status='OnTheWay';".format(oid)
	cursor.execute(str)
	connection.commit()
	
	str = "UPDATE DeliveryMan SET IsFree='1' WHERE UID='{}';".format(uid)
	cursor.execute(str)
	connection.commit()

def get_order_prods(uid, oid):
	str = "SELECT * FROM Orderio WHERE CustUID='{}' AND OID='{}';".format(uid, oid)
	cursor.execute(str)
	record = cursor.fetchall()
	str = "SELECT * FROM Orderio WHERE DelUID='{}' AND OID='{}';".format(uid, oid)
	cursor.execute(str)
	record2 = cursor.fetchall()
	str = "SELECT * FROM Orderio NATURAL JOIN OwnsStore WHERE UID='{}' AND OID='{}';".format(uid, oid)
	cursor.execute(str)
	record3 = cursor.fetchall()
	if len(record)==0 and len(record2)==0 and len(record3)==0:
		raise Exception("it's not your order")
	
	str = "SELECT PID, Countio FROM OrdProd WHERE OID='{}';".format(oid, uid)
	cursor.execute(str)
	record = cursor.fetchall()
	return record
	
def custom_command(str):
	if not admin:
		raise Exception("command not available for you")
	cursor.execute(str)
	record = cursor.fetchall()
	connection.commit()
	if len(record)!=0:
		return record
		